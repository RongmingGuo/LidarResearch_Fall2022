function [x, y, theta] = PelvisFrame(q)
    x = q(1);
    y = q(2);
    theta = q(3);
end